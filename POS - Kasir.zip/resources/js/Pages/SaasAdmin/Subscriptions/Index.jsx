import { Link } from '@inertiajs/react';
import SaasAdminLayout from '@/Layouts/SaasAdminLayout';
import { Eye } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent, Table, TableHeader, TableRow, TableHead, TableBody, TableCell, Badge } from '@/Components/UI';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';

export default function SubscriptionsIndex({ subscriptions }) {
    const getStatusBadge = (status) => {
        switch (status) {
            case 'active':
                return <Badge className="bg-emerald-100 text-emerald-700">Aktif</Badge>;
            case 'expired':
                return <Badge className="bg-rose-100 text-rose-700">Kedaluwarsa</Badge>;
            case 'cancelled':
                return <Badge className="bg-slate-100 text-slate-700">Dibatalkan</Badge>;
            case 'pending':
                return <Badge className="bg-amber-100 text-amber-700">Pending</Badge>;
            default:
                return <Badge className="bg-slate-100 text-slate-500">{status}</Badge>;
        }
    };

    return (
        <SaasAdminLayout title="Manajemen Subscriptions">
            <Card>
                <CardHeader className="border-b border-slate-100 pb-4">
                    <CardTitle className="text-lg font-bold text-slate-800">Daftar Langganan (Subscriptions)</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                    <Table>
                        <TableHeader>
                            <TableRow className="bg-slate-50/50">
                                <TableHead>Toko (Tenant)</TableHead>
                                <TableHead>Paket</TableHead>
                                <TableHead>Mulai</TableHead>
                                <TableHead>Berakhir</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead className="text-right">Aksi</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {subscriptions.map((sub) => (
                                <TableRow key={sub.id}>
                                    <TableCell className="font-medium text-slate-900">{sub.tenant?.name || 'Unknown'}</TableCell>
                                    <TableCell>{sub.plan?.name || 'Unknown'}</TableCell>
                                    <TableCell>
                                        {sub.starts_at ? format(new Date(sub.starts_at), 'dd MMM yyyy', { locale: id }) : '-'}
                                    </TableCell>
                                    <TableCell>
                                        {sub.ends_at ? format(new Date(sub.ends_at), 'dd MMM yyyy', { locale: id }) : '-'}
                                    </TableCell>
                                    <TableCell>{getStatusBadge(sub.status)}</TableCell>
                                    <TableCell className="text-right">
                                        <div className="flex justify-end gap-2">
                                            <Link href={route('admin.subscriptions.show', sub.id)}>
                                                <button className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                                                    <Eye className="w-4 h-4" />
                                                </button>
                                            </Link>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))}
                            {subscriptions.length === 0 && (
                                <TableRow>
                                    <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                                        Belum ada data langganan.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </SaasAdminLayout>
    );
}
