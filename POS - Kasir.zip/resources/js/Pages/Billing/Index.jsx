import { useState, useEffect } from 'react';
import { useForm, router, usePage } from '@inertiajs/react';
import AppLayout from '@/Layouts/AppLayout';
import { CreditCard, CheckCircle2, AlertCircle, FileText, Package } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent, Button, Badge, Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/Components/UI';
import { format } from 'date-fns';
import { id as localeId } from 'date-fns/locale';
import { toast } from 'sonner';

export default function BillingIndex({ currentSubscription, invoices, availablePlans, midtransClientKey, midtransEnvironment }) {
    const { flash } = usePage().props;
    const [selectedPlan, setSelectedPlan] = useState(null);
    const [billingCycle, setBillingCycle] = useState('monthly');
    const { data, setData, post, processing, errors } = useForm({
        plan_id: '',
        billing_cycle: 'monthly'
    });

    useEffect(() => {
        // Load Midtrans Snap Script dynamically
        if (midtransClientKey) {
            const scriptUrl = midtransEnvironment === 'production' 
                ? 'https://app.midtrans.com/snap/snap.js'
                : 'https://app.sandbox.midtrans.com/snap/snap.js';
                
            const script = document.createElement('script');
            script.src = scriptUrl;
            script.setAttribute('data-client-key', midtransClientKey);
            document.body.appendChild(script);

            return () => {
                document.body.removeChild(script);
            }
        }
    }, [midtransClientKey, midtransEnvironment]);

    useEffect(() => {
        // If the backend generated a snap token, trigger the popup
        if (flash?.snapToken) {
            if (window.snap) {
                window.snap.pay(flash.snapToken, {
                    onSuccess: function(result) {
                        toast.success('Pembayaran sukses! Langganan Anda akan segera aktif.');
                        router.reload();
                    },
                    onPending: function(result) {
                        toast.info('Menunggu pembayaran Anda...');
                        router.reload();
                    },
                    onError: function(result) {
                        toast.error('Pembayaran gagal atau dibatalkan.');
                    },
                    onClose: function() {
                        toast.warning('Anda menutup pop-up pembayaran sebelum menyelesaikannya.');
                    }
                });
            } else {
                toast.error('Midtrans Snap tidak dapat dimuat.');
            }
        }
    }, [flash]);

    const handleUpgrade = (plan) => {
        setSelectedPlan(plan);
        setData('plan_id', plan.id);
    };

    const confirmUpgrade = () => {
        post(route('billing.upgrade'), {
            preserveScroll: true,
            onSuccess: (page) => {
                // If it's manual fallback (no snapToken), just show success and clear selection
                if (!page.props.flash?.snapToken) {
                    toast.success(page.props.flash?.success || 'Paket berhasil diperbarui!');
                    setSelectedPlan(null);
                }
            }
        });
    };

    const getInvoiceStatus = (status) => {
        switch (status) {
            case 'paid':
                return <Badge className="bg-emerald-100 text-emerald-700">Lunas</Badge>;
            case 'unpaid':
                return <Badge className="bg-rose-100 text-rose-700">Belum Bayar</Badge>;
            case 'pending':
                return <Badge className="bg-amber-100 text-amber-700">Pending</Badge>;
            default:
                return <Badge className="bg-slate-100 text-slate-500">{status}</Badge>;
        }
    };

    return (
        <AppLayout title="Billing & Paket Langganan">
            <div className="max-w-6xl mx-auto space-y-8">
                
                {/* Header Status Saat Ini */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="bg-gradient-to-br from-blue-600 to-blue-800 text-white border-0 shadow-lg relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-10">
                            <Package className="w-32 h-32" />
                        </div>
                        <CardContent className="pt-6 pb-6 relative z-10">
                            <h2 className="text-blue-100 font-medium mb-1">Paket Saat Ini</h2>
                            <div className="flex items-end gap-3 mb-4">
                                <span className="text-3xl font-bold">{currentSubscription?.plan?.name || 'Free Plan'}</span>
                                {currentSubscription?.status === 'active' && (
                                    <Badge className="bg-blue-400/30 text-blue-50 border-0">Aktif</Badge>
                                )}
                            </div>
                            
                            <div className="space-y-2 text-sm text-blue-50">
                                <div className="flex justify-between">
                                    <span>Masa Aktif Berakhir:</span>
                                    <span className="font-semibold">
                                        {currentSubscription?.ends_at 
                                            ? format(new Date(currentSubscription.ends_at), 'dd MMM yyyy') 
                                            : 'Selamanya'}
                                    </span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Limit Produk:</span>
                                    <span className="font-semibold">
                                        {currentSubscription?.plan?.limits?.max_products == -1 ? 'Unlimited' : (currentSubscription?.plan?.limits?.max_products || 'Basic')}
                                    </span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Limit User Kasir:</span>
                                    <span className="font-semibold">
                                        {currentSubscription?.plan?.limits?.max_users == -1 ? 'Unlimited' : (currentSubscription?.plan?.limits?.max_users || 1)}
                                    </span>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="pb-3 border-b border-slate-100">
                            <CardTitle className="text-lg flex items-center gap-2">
                                <AlertCircle className="w-5 h-5 text-amber-500" /> Butuh Lebih Banyak Fitur?
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="pt-4 flex flex-col justify-center h-[calc(100%-60px)]">
                            <p className="text-slate-600 mb-4 text-sm">
                                Upgrade paket Anda untuk mendapatkan akses ke modul tambahan, kapasitas produk yang lebih besar, dan dukungan prioritas.
                            </p>
                            <Button 
                                onClick={() => document.getElementById('pricing-plans').scrollIntoView({ behavior: 'smooth' })}
                                className="w-full bg-slate-900 hover:bg-slate-800 text-white rounded-xl py-2.5"
                            >
                                Lihat Pilihan Paket
                            </Button>
                        </CardContent>
                    </Card>
                </div>

                {/* Pilih Paket Baru */}
                <div id="pricing-plans" className="pt-8">
                    <div className="text-center mb-8">
                        <h2 className="text-2xl font-bold text-slate-900 mb-2">Upgrade Paket Anda</h2>
                        <p className="text-slate-500">Pilih paket yang paling sesuai dengan kebutuhan bisnis Anda.</p>
                        
                        <div className="inline-flex items-center bg-slate-100 p-1 rounded-xl mt-6">
                            <button 
                                onClick={() => { setBillingCycle('monthly'); setData('billing_cycle', 'monthly'); }}
                                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${billingCycle === 'monthly' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                            >
                                Bulanan
                            </button>
                            <button 
                                onClick={() => { setBillingCycle('yearly'); setData('billing_cycle', 'yearly'); }}
                                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${billingCycle === 'yearly' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                            >
                                Tahunan (Hemat 20%)
                            </button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {availablePlans.map((plan) => (
                            <Card key={plan.id} className={`relative transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border-2 ${selectedPlan?.id === plan.id ? 'border-blue-600 shadow-lg shadow-blue-100' : 'border-transparent'}`}>
                                {selectedPlan?.id === plan.id && (
                                    <div className="absolute top-0 right-0 bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-bl-xl rounded-tr-xl">
                                        Dipilih
                                    </div>
                                )}
                                <CardHeader className="text-center pb-0">
                                    <h3 className="text-xl font-bold text-slate-800">{plan.name}</h3>
                                    <p className="text-slate-500 text-sm mt-1">{plan.description}</p>
                                </CardHeader>
                                <CardContent className="pt-6 text-center space-y-6">
                                    <div>
                                        <span className="text-3xl font-extrabold text-slate-900">
                                            Rp {billingCycle === 'monthly' ? parseInt(plan.price_monthly).toLocaleString('id-ID') : parseInt(plan.price_yearly).toLocaleString('id-ID')}
                                        </span>
                                        <span className="text-slate-500 text-sm">/{billingCycle === 'monthly' ? 'bulan' : 'tahun'}</span>
                                    </div>
                                    
                                    <div className="space-y-3 text-left">
                                        <div className="flex items-start gap-2">
                                            <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                                            <span className="text-sm text-slate-700"><strong>{plan.limits?.max_products == -1 ? 'Unlimited' : plan.limits?.max_products}</strong> Produk</span>
                                        </div>
                                        <div className="flex items-start gap-2">
                                            <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                                            <span className="text-sm text-slate-700"><strong>{plan.limits?.max_users == -1 ? 'Unlimited' : plan.limits?.max_users}</strong> User Kasir/Staf</span>
                                        </div>
                                        
                                        {/* Modul/Fitur Ekstra */}
                                        {plan.features?.map(featureKey => (
                                            <div key={featureKey} className="flex items-start gap-2">
                                                <CheckCircle2 className="w-5 h-5 text-blue-500 shrink-0" />
                                                <span className="text-sm text-slate-700">Modul {featureKey.replace('-', ' ').toUpperCase()}</span>
                                            </div>
                                        ))}
                                    </div>

                                    <Button 
                                        onClick={() => handleUpgrade(plan)}
                                        className={`w-full py-2.5 rounded-xl ${
                                            currentSubscription?.plan_id === plan.id
                                                ? 'bg-slate-100 text-slate-500 cursor-not-allowed hover:bg-slate-100' 
                                                : selectedPlan?.id === plan.id 
                                                    ? 'bg-blue-700 hover:bg-blue-800 text-white' 
                                                    : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                                        }`}
                                        disabled={currentSubscription?.plan_id === plan.id}
                                    >
                                        {currentSubscription?.plan_id === plan.id ? 'Paket Aktif' : 'Pilih Paket Ini'}
                                    </Button>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    {selectedPlan && currentSubscription?.plan_id !== selectedPlan.id && (
                        <div className="mt-8 bg-white border border-blue-100 p-6 rounded-2xl shadow-sm flex flex-col md:flex-row items-center justify-between animate-in fade-in slide-in-from-bottom-4">
                            <div>
                                <h4 className="font-bold text-slate-800 text-lg">Konfirmasi Upgrade</h4>
                                <p className="text-slate-500 text-sm">Anda memilih <strong>{selectedPlan.name}</strong> dengan penagihan {billingCycle === 'monthly' ? 'Bulanan' : 'Tahunan'}.</p>
                                <p className="text-sm text-blue-600 mt-1">Total Tagihan: Rp {billingCycle === 'monthly' ? parseInt(selectedPlan.price_monthly).toLocaleString('id-ID') : parseInt(selectedPlan.price_yearly).toLocaleString('id-ID')}</p>
                            </div>
                            <Button 
                                onClick={confirmUpgrade} 
                                disabled={processing}
                                className="mt-4 md:mt-0 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl px-8 py-3 flex items-center gap-2"
                            >
                                <CreditCard className="w-5 h-5" />
                                Bayar & Aktifkan Sekarang
                            </Button>
                        </div>
                    )}
                </div>

                {/* Riwayat Tagihan */}
                <div className="pt-8">
                    <Card>
                        <CardHeader className="border-b border-slate-100 pb-4">
                            <CardTitle className="text-lg font-bold flex items-center gap-2">
                                <FileText className="w-5 h-5 text-slate-600" /> Riwayat Tagihan (Invoices)
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <Table>
                                <TableHeader>
                                    <TableRow className="bg-slate-50/50">
                                        <TableHead>No. Invoice</TableHead>
                                        <TableHead>Total (Rp)</TableHead>
                                        <TableHead>Status</TableHead>
                                        <TableHead>Tgl Tagihan</TableHead>
                                        <TableHead>Tgl Bayar</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {invoices?.map((invoice) => (
                                        <TableRow key={invoice.id}>
                                            <TableCell className="font-medium text-slate-700">{invoice.invoice_number}</TableCell>
                                            <TableCell>Rp {parseInt(invoice.amount).toLocaleString('id-ID')}</TableCell>
                                            <TableCell>{getInvoiceStatus(invoice.status)}</TableCell>
                                            <TableCell>{format(new Date(invoice.created_at), 'dd MMM yyyy', { locale: localeId })}</TableCell>
                                            <TableCell>{invoice.paid_at ? format(new Date(invoice.paid_at), 'dd MMM yyyy', { locale: localeId }) : '-'}</TableCell>
                                        </TableRow>
                                    ))}
                                    {(!invoices || invoices.length === 0) && (
                                        <TableRow>
                                            <TableCell colSpan={5} className="text-center py-6 text-slate-500">
                                                Belum ada riwayat tagihan.
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </div>

            </div>
        </AppLayout>
    );
}
