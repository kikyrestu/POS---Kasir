import { useState } from 'react';
import { Link, usePage } from '@inertiajs/react';
import { LayoutDashboard, Users, LogOut, Menu, X, Store, Settings, CreditCard } from 'lucide-react';

export default function SaasAdminLayout({ children }) {
    const { auth } = usePage().props;
    const [sidebarOpen, setSidebarOpen] = useState(false);

    const navigation = [
        { name: 'Dashboard', href: route('admin.dashboard'), icon: LayoutDashboard },
        { name: 'Tenants', href: route('admin.tenants.index'), icon: Store },
        { name: 'Plans', href: route('admin.plans.index'), icon: CreditCard },
        { name: 'Subscriptions', href: route('admin.subscriptions.index'), icon: Users },
        { name: 'Features', href: route('admin.features.index'), icon: Settings },
        { name: 'Global Settings', href: route('admin.settings.index'), icon: Settings },
    ];

    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* Sidebar */}
            <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transform transition-transform duration-200 ease-in-out lg:static lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                <div className="h-16 flex items-center px-6 border-b border-gray-200">
                    <span className="text-xl font-bold text-primary-600">NEXA<span className="text-gray-900">SaaS</span></span>
                    <button className="ml-auto lg:hidden" onClick={() => setSidebarOpen(false)}>
                        <X className="w-6 h-6 text-gray-500" />
                    </button>
                </div>
                <nav className="p-4 space-y-1">
                    {navigation.map((item) => {
                        const active = route().current(item.href.split('?')[0].split('/').pop() + '*'); // basic active check
                        return (
                            <Link
                                key={item.name}
                                href={item.href}
                                className={`flex items-center px-4 py-2.5 text-sm font-medium rounded-xl transition-colors ${
                                    active
                                        ? 'bg-primary-50 text-primary-700'
                                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                                }`}
                            >
                                <item.icon className={`mr-3 w-5 h-5 ${active ? 'text-primary-600' : 'text-gray-400'}`} />
                                {item.name}
                            </Link>
                        );
                    })}
                </nav>
            </aside>

            {/* Main Content */}
            <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
                <header className="h-16 bg-white border-b border-gray-200 flex items-center px-4 sm:px-6 justify-between lg:justify-end">
                    <button className="lg:hidden text-gray-500" onClick={() => setSidebarOpen(true)}>
                        <Menu className="w-6 h-6" />
                    </button>
                    <div className="flex items-center gap-4">
                        <span className="text-sm font-medium text-gray-700">{auth?.user?.name}</span>
                        <Link
                            href={route('admin.logout')}
                            method="post"
                            as="button"
                            className="text-gray-500 hover:text-gray-700"
                        >
                            <LogOut className="w-5 h-5" />
                        </Link>
                    </div>
                </header>
                <main className="flex-1 overflow-auto p-4 sm:p-6 lg:p-8">
                    {children}
                </main>
            </div>
        </div>
    );
}
