<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class SaasAdmin extends Authenticatable
{
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];
}
