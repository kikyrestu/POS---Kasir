<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SaasFeature extends Model
{
    protected $connection = 'sqlite'; // Ensure it always queries the central DB, even in tenant context

    protected $fillable = [
        'key',
        'name',
        'description',
        'status',
    ];
}
