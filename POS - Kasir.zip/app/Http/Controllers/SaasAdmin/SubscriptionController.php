<?php

namespace App\Http\Controllers\SaasAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Subscription;
use Inertia\Inertia;

class SubscriptionController extends Controller
{
    public function index()
    {
        $subscriptions = Subscription::with(['tenant', 'plan'])->latest()->get();
        return Inertia::render('SaasAdmin/Subscriptions/Index', [
            'subscriptions' => $subscriptions
        ]);
    }

    public function show($id)
    {
        $subscription = Subscription::with(['tenant', 'plan', 'invoices'])->findOrFail($id);
        return Inertia::render('SaasAdmin/Subscriptions/Show', [
            'subscription' => $subscription
        ]);
    }
}
