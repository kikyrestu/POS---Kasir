<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\Invoice;
use Carbon\Carbon;

class BillingController extends Controller
{
    public function index()
    {
        $tenant = tenant();
        $currentSubscription = $tenant->currentSubscription()->with('plan')->first();
        $invoices = $tenant->invoices()->latest()->get();
        $availablePlans = Plan::where('is_active', true)->get();

        return Inertia::render('Billing/Index', [
            'currentSubscription' => $currentSubscription,
            'invoices' => $invoices,
            'availablePlans' => $availablePlans,
            'midtransClientKey' => \App\Models\SaasSetting::getVal('midtrans_client_key'),
            'midtransEnvironment' => \App\Models\SaasSetting::getVal('midtrans_environment', 'sandbox'),
        ]);
    }

    public function upgrade(Request $request)
    {
        $validated = $request->validate([
            'plan_id' => 'required|exists:plans,id',
            'billing_cycle' => 'required|in:monthly,yearly'
        ]);

        $tenant = tenant();
        $plan = Plan::findOrFail($validated['plan_id']);

        // Check if Midtrans is enabled
        $midtransEnabled = \App\Models\SaasSetting::getVal('midtrans_enabled', '0') === '1';

        // Get environment and keys
        $isProduction = \App\Models\SaasSetting::getVal('midtrans_environment', 'sandbox') === 'production';
        $serverKey = \App\Models\SaasSetting::getVal('midtrans_server_key', env('MIDTRANS_SERVER_KEY'));
        
        \Midtrans\Config::$serverKey = $serverKey;
        \Midtrans\Config::$isProduction = $isProduction;
        \Midtrans\Config::$isSanitized = true;
        \Midtrans\Config::$is3ds = true;

        $amount = $validated['billing_cycle'] === 'monthly' ? $plan->price_monthly : $plan->price_yearly;
        $orderId = 'INV-' . strtoupper(uniqid());

        $invoice = Invoice::create([
            'tenant_id' => $tenant->id,
            'subscription_id' => null, // Will update via webhook or manually below
            'invoice_number' => $orderId,
            'amount' => $amount,
            'status' => $midtransEnabled ? 'unpaid' : 'paid', 
            'paid_at' => $midtransEnabled ? null : now(),
            'due_date' => now()->addDays(3),
        ]);

        $duration = $validated['billing_cycle'] === 'monthly' ? 1 : 12;
        
        if (!$midtransEnabled) {
            // Manual fallback / dummy payment
            $currentSubscription = $tenant->currentSubscription()->first();
            if ($currentSubscription && $currentSubscription->status === 'active') {
                $currentSubscription->update(['status' => 'cancelled']);
            }
            $subscription = Subscription::create([
                'tenant_id' => $tenant->id,
                'plan_id' => $plan->id,
                'status' => 'active',
                'starts_at' => now(),
                'ends_at' => now()->addMonths($duration)
            ]);
            $invoice->update(['subscription_id' => $subscription->id]);
            return redirect()->route('billing.index')->with('success', 'Paket berhasil di-upgrade secara manual.');
        }

        // Midtrans flow: create pending subscription
        $subscription = Subscription::create([
            'tenant_id' => $tenant->id,
            'plan_id' => $plan->id,
            'status' => 'pending',
            'starts_at' => now(),
            'ends_at' => now()->addMonths($duration)
        ]);
        $invoice->update(['subscription_id' => $subscription->id]);

        // Generate Snap Token
        $params = array(
            'transaction_details' => array(
                'order_id' => $orderId,
                'gross_amount' => (int) $amount,
            ),
            'customer_details' => array(
                'first_name' => auth()->user()->name,
                'email' => auth()->user()->email,
            ),
            'item_details' => array(
                [
                    'id' => $plan->id,
                    'price' => (int) $amount,
                    'quantity' => 1,
                    'name' => 'Langganan ' . $plan->name . ' (' . ucfirst($validated['billing_cycle']) . ')'
                ]
            )
        );

        try {
            $snapToken = \Midtrans\Snap::getSnapToken($params);
            
            // Return back with snap token so frontend can trigger payment
            return redirect()->back()->with('snapToken', $snapToken);
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal memproses pembayaran: ' . $e->getMessage());
        }
    }
}

